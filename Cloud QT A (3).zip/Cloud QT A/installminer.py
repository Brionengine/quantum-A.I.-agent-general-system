pip install scikit-learn pandas numpy
